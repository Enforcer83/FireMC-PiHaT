#ifndef VERSION_H
#define VERSION_H
#ifdef __cplusplus
extern "C" {
#endif

//////////// GENERATED FILE (from version.h.in) /////////////////
//////////// GENERATED FILE (from version.h.in) /////////////////
//////////// GENERATED FILE (from version.h.in) /////////////////

#define VERSION_MAJOR 1
#define VERSION_MINOR 9
#define VERSION_PATCH 0

//////////// GENERATED FILE (from version.h.in) /////////////////
//////////// GENERATED FILE (from version.h.in) /////////////////
//////////// GENERATED FILE (from version.h.in) /////////////////

#ifdef __cplusplus
}
#endif
#endif
